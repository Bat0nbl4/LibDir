<footer>
    <div class="footer_display">
        <a class="logo white" href="<?php echo \vendor\routing\Router::route("index") ?>">
            <img src="<?php echo \vendor\helpers\Resource::resource("img/system/logo.svg") ?>">
            <div class="logo-text">
                <span>Библиотека</span>
                <h2>Lib Directory</h2>
            </div>
        </a>
        <div class="flex row gap-5 contacts align-items">
            <a href="https://vk.com/" class="contact">
                <img src="<?php echo \vendor\helpers\Resource::resource("img/system/vk.svg") ?>" alt="">
            </a>
            <a href="https://web.telegram.org/" class="contact">
                <img src="<?php echo \vendor\helpers\Resource::resource("img/system/tg.svg") ?>" alt="">
            </a>
            <a href="https://web.whatsapp.com/" class="contact">
                <img src="<?php echo \vendor\helpers\Resource::resource("img/system/whatsapp.svg") ?>" alt="">
            </a>
        </div>
        <p class="desc">
            Если увас есть идеи, пожелания или предложения о сотрудничестве , напишите нам напочту: example@mail.ru
            <br><br>
            Наш адрес: ул. Братухина 42
        </p>
    </div>
</footer>