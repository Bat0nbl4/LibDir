<header>
    <div class="flex row gap-10 p10-5on350 align-items">
        <a class="logo" href="<?php echo \vendor\routing\Router::route("index") ?>">
            <img src="<?php echo \vendor\helpers\Resource::resource("img/system/logo.svg") ?>">
            <div class="logo-text hidden-500">
                <span>Библиотека</span>
                <h2>Lib Directory</h2>
            </div>
        </a>
        <form class="hidden-650 w100" method="post" action=<?php echo \vendor\routing\Router::route("search_book")?>#" class="w100">
            <label for="search" class="search center">
                <button class="btn blue" type="submit">Поиск</button>
                <input type="text" id="search" name="title" placeholder="Какую книгу вы ищите?" value="<?php echo \vendor\session\Session::hasFlash("search") ? \vendor\session\Session::getFlash("search") : "" ?>">
                <img class="loupe" src="<?php echo \vendor\helpers\Resource::resource("img/system/loupe.svg") ?>">
            </label>
        </form>
        <div class="menu-icon" id="MenuBtn">
            <img src="<?php echo \vendor\helpers\Resource::resource("img/system/menu.svg") ?>">
        </div>
    </div>
    <div class="menu" id="MainMenu">
        <form class="showOn650 w100" method="post" action=<?php echo \vendor\routing\Router::route("search_book")?>#" class="w100">
            <label for="search" class="search center">
                <button class="btn blue" type="submit">Поиск</button>
                <input type="text" id="search" name="title" placeholder="Какую книгу вы ищите?" value="<?php echo \vendor\session\Session::hasFlash("search") ? \vendor\session\Session::getFlash("search") : "" ?>">
                <img class="loupe" src="<?php echo \vendor\helpers\Resource::resource("img/system/loupe.svg") ?>">
            </label>
        </form>
        <div class="title"><span>Навигация</span></div>
        <nav>
            <div class="menu-group">
                <h2>Пользователь</h2>
                <?php if (vendor\session\Session::has("user")): ?>
                    <a href="<?php echo \vendor\routing\Router::route("logout"); ?>">logout</a>
                    <a href="<?php echo \vendor\routing\Router::route("lk"); ?>">lk</a>
                <?php else: ?>
                    <a href="<?php echo \vendor\routing\Router::route("reg"); ?>">reg</a>
                    <a href="<?php echo \vendor\routing\Router::route("login"); ?>">login</a>
                <?php endif; ?>
                <a href="#">point</a>
                <a href="#">point</a>
                <a href="#">point</a>
            </div>
            <div class="menu-group">
                <h2>Библиотека</h2>
                <a href="#">point</a>
                <a href="#">point</a>
                <a href="#">point</a>
                <a href="#">point</a>
                <a href="#">point</a>
            </div>
        </nav>
    </div>
</header>